import BaseLayout from "@/components/BaseLayout";

const About = () => {
  return <BaseLayout>About Page</BaseLayout>;
};

export default About;
