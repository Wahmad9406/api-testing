import BaseLayout from "../components/BaseLayout";
import { LiaShippingFastSolid } from 'react-icons/lia';

const Home = () => {
  return <BaseLayout>
  <div className="mt50">
  <div class="container-fluid">
  <div class="row">
    <div class="col-4 pr0">
    <div className="box-shadow shadow-sm p15">
    <div class="row">
    <div class="col">
    <div class="d-flex justify-content-start">
      <div class="rounded-circle text-center mr-10 bg-red circle50">
  <LiaShippingFastSolid className="text-white font30" />
        </div>
        <div class="">
          <p class="font13 text-gray m-0">Today’s Order</p>
          <h2 class="font20 title-text p-y bold-600 m0">2,543</h2>
          <p class="font12 text-red">Created 159 </p>
          </div>
          </div>    
</div>
    <div class="col">
    <div className="text-end">
                        <img src="graph-red.png" className="inline-block" />
                        <span className="text-color font13 pt20 bold-600 d-block">
                          +40%
                        </span>
                        <p className="text-xs text-gray font13 m0 text-gray-600">
                        this month
                        </p>
                      </div>

                      
    </div>
  </div>
  <div className="row">
    <div className="col">
    <div className="progress-widget mt50">
                      <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">Yet to Pick</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress mb-15">
                        <div className="progress-bar bg-blue w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">Picked</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress mb-15">
                        <div className="progress-bar bg-red w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">In-Transit</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress mb-15">
                        <div className="progress-bar bg-green w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">Out Of Delivery</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress  mb-15">
                        <div className="progress-bar bg-orange w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">Delivered</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress  mb-15">
                        <div className="progress-bar bg-aqua w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">NDR</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress mb-15">
                        <div className="progress-bar bg-purple w50" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-between">
                            <p className="font12 bold-600 mb-10">RTO</p>
                            <p className="font12 bold-600 mb-10">1,22 <span className="text-gray-light ">(40%)</span></p>
                          </div>
                          
                        <div className="progress">
                        <div className="progress-bar bg-pink w50" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                       

                       
                      </div>
    </div>
  </div>
  </div>
    </div>
    <div class="col-4 pr0">
    <div class="grid gap-3">
  <div class="g-col-6">
  <div className="box-shadow shadow-sm">sas</div>
  </div>
  <div class="g-col-6">
  <div className="box-shadow shadow-sm">sas</div>
  </div>

  <div class="g-col-6">
  <div className="box-shadow shadow-sm">sas</div>
  </div>

  <div class="g-col-6">
  <div className="box-shadow shadow-sm">sas</div>
  </div>
</div>
    </div>
    <div class="col-4">
    <div className="box-shadow shadow-sm">rigjt</div>
    </div>
    
  </div>
</div>
  </div>
  
  </BaseLayout>;
};

export default Home;
