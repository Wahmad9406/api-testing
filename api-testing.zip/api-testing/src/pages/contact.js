import BaseLayout from "@/components/BaseLayout";

const Contact = () => {
  return <BaseLayout>Contact Page</BaseLayout>;
};

export default Contact;
