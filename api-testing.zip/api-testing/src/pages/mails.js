import BaseLayout from "@/components/BaseLayout";

const Mails = () => {
  return <BaseLayout>Mails Page</BaseLayout>;
};

export default Mails;
